import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;

/**
 * The common implementation for {@link GenericsKbArrayApp} and {@link GenericsKbBSTApp}.
 *
 * @see GenericsKbArrayApp
 * @see GenericsKbBSTApp
 * @see KnowledgeBase
 * @see KnowledgeBaseArray
 * @see KnowledgeBaseBST
 *
 * @author Adam Foflonker (FFLADA001)
 * @version 05/03/25
 */
public class GenericsKbApp
{
    /**
     * The type of {@link KnowledgeBase} backend data structure implementation to use.
     *
     * @see KnowledgeBaseArray
     * @see KnowledgeBaseBST
     */
    public enum KnowledgeBaseType
    {
        /** Specifies that the backend knowledge base should be implemented as an {@code array}. */
        Array,

        /** Specifies that the backend knowledge base should be implemented as a {@link BinarySearchTree}. */
        BinarySearchTree
    }

    /**
     * Constructs a new {@link GenericsKbApp}.
     *
     * @param appName the name of the app
     * @param kbType the {@link KnowledgeBaseType} to use for the backend {@link KnowledgeBase}.
     */
    public GenericsKbApp(String appName, KnowledgeBaseType kbType)
    {
        m_AppName = appName;
        m_KnowledgeBaseType = kbType;
    }

    /**
     * Runs the program.
     */
    public void Run()
    {
        Console.WriteLine("--------%s--------", m_AppName);

        while (true)
        {
            String kBPath = (m_KnowledgeBase != null) ? m_KnowledgeBase.GetKnowledgeBasePath() : "";

            Console.WriteLine("Choose an action from the menu:");
            Console.WriteLine("1. Load a knowledge base from a file");
            Console.WriteLine("2. Update a statement in the knowledge base");
            Console.WriteLine("3. Update knowledge base from file");
            Console.WriteLine("4. Search for a statement in the knowledge base by term");
            Console.WriteLine("5. Search for all statements in the knowledge base by term");
            Console.WriteLine("6. Search for all statements in the knowledge base by partial term");
            Console.WriteLine("7. Search for a statement in the knowledge base by term and sentence");
            Console.WriteLine("8. Quit");
            Console.Write("%s> ", kBPath);

            int option = Integer.parseInt(Console.ReadLine());
            if (option == 8)
                break;      // Exit application loop

            switch (option)
            {
                case 1: LoadKnowledgeBaseImpl(); break;
                case 2: UpdateStatementImpl(); break;
                case 3: UpdateFromFileImpl(); break;
                case 4: SearchByTermImpl(); break;
                case 5: SearchAllByTermImpl(); break;
                case 6: SearchAllByPartialTermImpl(); break;
                case 7: SearchByTermAndSentenceImpl(); break;
            }
        }

        Console.WriteLine("\nShutting down...");
    }

    // Load knowledge base
    private void LoadKnowledgeBaseImpl()
    {
        String fileName;
        while (true)
        {
            Console.Write("Enter file name: ");
            fileName = Console.ReadLine();

            if ((new File(fileName)).exists())
                break;

            Console.WriteLine("\nFile does not exist, please enter a valid file name!\n");
        }

        try
        {
            switch (m_KnowledgeBaseType)
            {
                case KnowledgeBaseType.Array: m_KnowledgeBase = new KnowledgeBaseArray(fileName); break;
                case KnowledgeBaseType.BinarySearchTree: m_KnowledgeBase = new KnowledgeBaseBST(fileName); break;
            }

            Console.WriteLine("\nKnowledge base loaded successfully.\n");
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    // Update or add a statement in the knowledge base
    private void UpdateStatementImpl()
    {
        Console.Write("Enter the term to update: ");
        String searchTerm = Console.ReadLine();

        Statement st = m_KnowledgeBase.LookupStatement(searchTerm);
        if (st == null)
        {
            Console.WriteLine("\nSearch term not found! A new statement will now be created for the term '%s'.\n",
                searchTerm);

            Statement newSt = new Statement();
            newSt.SetTerm(searchTerm);

            Console.Write("Enter the sentence: ");
            newSt.SetSentence(Console.ReadLine());

            Console.Write("Enter the confidence score: ");
            newSt.SetConfidence(Double.parseDouble(Console.ReadLine()));

            if (m_KnowledgeBase.AddStatement(newSt))
                Console.WriteLine("\nStatement for the term '%s' has been added.\n", newSt.GetTerm());
            else
                Console.WriteLine("\nFailed to add new statement!\n");

            return;
        }

        Console.WriteLine("\nOriginal statement: %s (Confidence score: %.2f).", st.GetSentence(), st.GetConfidence());

        Console.Write("Enter the updated sentence: ");
        String newSentence = Console.ReadLine();

        Console.Write("Enter the new confidence score: ");
        double newConfidence = Double.parseDouble(Console.ReadLine());

        if (newConfidence >= st.GetConfidence())
        {
            Statement updatedSt = new Statement(st);
            updatedSt.SetSentence(newSentence);
            updatedSt.SetConfidence(newConfidence);

            if (m_KnowledgeBase.UpdateStatement(st, updatedSt))
                Console.WriteLine("\nStatement updated.\n");
            else
                Console.WriteLine("\nFailed to update statement!\n");
        }
        else
            Console.WriteLine("\nStatement not updated! A statement for the term '%s' already exists with a higher confidence score.\n",
                searchTerm);
    }

    // Update knowledge base from file
    private void UpdateFromFileImpl()
    {
        String fileName;
        while (true)
        {
            Console.Write("Enter the other knowledge base file path: ");
            fileName = Console.ReadLine();

            if (fileName.equals(m_KnowledgeBase.GetKnowledgeBasePath()))
            {
                Console.WriteLine("\nCannot load the same knowledge base twice!\n");
                continue;
            }

            if ((new File(fileName)).exists())
                break;

            Console.WriteLine("\nFile does not exist, please enter a valid file name!\n");
        }

        Console.Write("\nUpdating knowledge base, this action may take a while...");

        try
        {
            int updates = 0;
            int adds = 0;
            for (String lineBuf : Files.readAllLines(Paths.get(fileName)))
            {
                Statement newSt = new Statement(lineBuf);
                Statement oldSt = m_KnowledgeBase.LookupStatement(newSt.GetTerm());

                if (oldSt == null)
                {
                    m_KnowledgeBase.AddStatement(newSt);
                    adds++;

                    continue;
                }

                if (newSt.GetConfidence() >= oldSt.GetConfidence())
                {
                    m_KnowledgeBase.UpdateStatement(oldSt, newSt);
                    updates++;
                }
            }

            Console.WriteLine("\nDone!");
            Console.WriteLine("Updated %d statements.", updates);
            Console.WriteLine("Added %d statements.\n", adds);
        }
        catch (IOException e)
        {
            Console.WriteLine("\nFailed to update knowledge base!\n");
            return;
        }
    }

    // Search the knowledge base by term
    private void SearchByTermImpl()
    {
        Console.Write("Enter the term to search: ");
        String searchTerm = Console.ReadLine();

        Statement st = m_KnowledgeBase.LookupStatement(searchTerm);
        if (st != null)
        {
            Console.WriteLine("\nStatement found: %s (Confidence score: %.2f).\n", st.GetSentence(), st.GetConfidence());
            return;
        }

        Console.WriteLine("\nStatement could not be found!\n");
    }

    // Search for all statements matching a term in the knowledge base
    private void SearchAllByTermImpl()
    {
        Console.Write("Enter the term to search: ");
        String searchTerm = Console.ReadLine();

        ArrayList<Statement> statements = m_KnowledgeBase.LookupAllStatements(searchTerm);
        if (statements.isEmpty())
        {
            Console.WriteLine("\nNo statements were found!\n");
            return;
        }

        Console.WriteLine("");

        int i = 1;
        for (final Statement st : statements)
        {
            Console.WriteLine("%d. Statement found: %s (Confidence score: %.2f).", i++,
                st.GetSentence(), st.GetConfidence());
        }

        Console.WriteLine("");
    }

    // Search for all statements matching a partial term in the knowledge base
    private void SearchAllByPartialTermImpl()
    {
        Console.Write("Enter the partial term to search: ");
        String partialTerm = Console.ReadLine();

        ArrayList<Statement> statements = m_KnowledgeBase.LookupAllStatementsByPartialTerm(partialTerm);
        if (statements.isEmpty())
        {
            Console.WriteLine("\nNo statements were found!\n");
            return;
        }

        Console.WriteLine("");

        int i = 1;
        for (final Statement st : statements)
        {
            Console.WriteLine("%d. %s: %s (Confidence score: %.2f).", i++,
                st.GetTerm(), st.GetSentence(), st.GetConfidence());
        }

        Console.WriteLine("");
    }

    // Search for a term and sentence in the knowledge base
    private void SearchByTermAndSentenceImpl()
    {
        Console.Write("Enter the term: ");
        String term = Console.ReadLine();

        Console.Write("Enter the statement to search for: ");
        String sentence = Console.ReadLine();

        Statement st = m_KnowledgeBase.LookupStatement(term, sentence);
        if (st != null)
        {
            Console.WriteLine("\nThe statement was found and has a confidence score of %.2f.\n", st.GetConfidence());
            return;
        }

        Console.WriteLine("\nStatement could not be found!\n");
    }

    /** This app's KnowledgeBase. */
    protected KnowledgeBase m_KnowledgeBase;

    /** This app's name. */
    protected String m_AppName;

    /** This app's KnowledgeBaseType. */
    protected KnowledgeBaseType m_KnowledgeBaseType;
}
